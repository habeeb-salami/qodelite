<?php

//all databsase settings goes in here
//database host name
$dbconfig['host'] = "127.0.0.1";
//database username
$dbconfig['username'] = "root";
//database password
$dbconfig['password'] = "hab552";
//database name on the server
$dbconfig['database'] = "payment-gateway";
//database driver mysql for now other may follow suit in other release
$dbconfig['dbdriver'] = "mysql";
/**
 * database settings */
$dsn = array("host" => "localhost",
    "dbname" => 'gameshow',
    "username" => 'root',
    "password" => 'hab552');
