<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Game Show System</title>
    </head>
    <body>
        <div class="container">
            <header class="header" id="header">
                <h1>The Game show system</h1>
            </header>
            <div class="row">

                <a href="login/">Login</a>
            </div>
        </div>
    </body>
</html>
