<?php

/* Contain the default route for the application
 */

$routes = array();
$routes['default'] = 'users/index'; //the defaul router
$routes['error'] = 'error/index'; //the defauflt error page
/*$routes['login'] = 'index/index/login';
$routes['send_message'] = 'index/page/send_message';
$routes['message_log'] = 'index/page/message_log';
$routes['student'] = 'studentresults';
$routes['processor'] = 'processor/index';*/
