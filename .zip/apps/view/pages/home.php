<?php 
echo 'Hello World from the home page of the system';
?>