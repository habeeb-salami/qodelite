<?php
require_once dirname(__FILE__).'/../Mobile_Detect.php';
