<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title>Login</title>
    </head>
    <body>
        <h1>Please Login</h1>
        <div>
            <form>
                <p>
                    <input name="username" id="username" placeholder="Username"/>
                </p>
                <p>
                    <input type="password" name="password" id="password" placeholder="Password"/>
                </p>
                <p>
                    <input type="submit" name="login" id="login" />
                </p>
                <a href="register/">Sign Up here</a>
            </form>
        </div>
    </body>
</html>
